﻿using System;
using System.Collections.Generic;

namespace ORGANISATION_X.Models
{
    public partial class LoginModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
